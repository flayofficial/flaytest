function _0x2822(_0x149c4c, _0x186e7d) {
    const _0x252bd1 = _0x379f();
    return _0x2822 = function (_0x552380, _0xc11e60) {
        _0x552380 = _0x552380 - (-0x2 * 0x135 + -0x61 * 0xa + 0x6b9);
        let _0x5c73af = _0x252bd1[_0x552380];
        return _0x5c73af;
    }, _0x2822(_0x149c4c, _0x186e7d);
}
const _0x16dda0 = _0x2822;
(function (_0x5dac63, _0x2ff608) {
    const _0x2552ca = _0x2822, _0x19f6fe = _0x5dac63();
    while (!![]) {
        try {
            const _0x3a1bf8 = parseInt(_0x2552ca(0x8e)) / (-0x1 * 0x40d + 0x25 + -0x5b * -0xb) + parseInt(_0x2552ca(0x8d)) / (-0xd1b * -0x1 + -0x1 * 0x2185 + 0x146c) + -parseInt(_0x2552ca(0xd2)) / (-0x7b * 0x32 + -0x596 + 0x1 * 0x1d9f) * (parseInt(_0x2552ca(0x90)) / (0x1096 + 0x119 * 0xb + -0x1 * 0x1ca5)) + parseInt(_0x2552ca(0x119)) / (-0xff + -0x58 * 0x11 + 0x6dc) * (parseInt(_0x2552ca(0xe4)) / (0xc1e + -0x1a95 * -0x1 + -0x1 * 0x26ad)) + parseInt(_0x2552ca(0xae)) / (-0x217b + 0x1be8 * 0x1 + 0x2cd * 0x2) * (parseInt(_0x2552ca(0xa4)) / (-0x1226 + 0x704 * 0x1 + 0x595 * 0x2)) + parseInt(_0x2552ca(0xdb)) / (0x1723 + 0x110 * -0x20 + 0x2d * 0x3e) + -parseInt(_0x2552ca(0xb0)) / (-0x1 * -0x2020 + 0x1 * 0x125d + -0x23 * 0x171);
            if (_0x3a1bf8 === _0x2ff608)
                break;
            else
                _0x19f6fe['push'](_0x19f6fe['shift']());
        } catch (_0x5940a5) {
            _0x19f6fe['push'](_0x19f6fe['shift']());
        }
    }
}(_0x379f, 0x19581 * -0x2 + -0xa26 * -0xac + 0x510));
const fs = require('fs'), count = process[_0x16dda0(0xaa)][-0x1 * -0x266d + -0x1b * -0x51 + -0x2 * 0x177b], uafile = process[_0x16dda0(0xaa)][-0x1 * 0x20fb + 0xb * 0x209 + -0x21f * -0x5];
process[_0x16dda0(0xaa)][_0x16dda0(0x97)] < -0x1c6d + 0x25d5 + -0x1 * 0x964 && (console[_0x16dda0(0x9b)](_0x16dda0(0xf3) + _0x16dda0(0x125) + _0x16dda0(0x140) + _0x16dda0(0xce) + _0x16dda0(0xc1) + _0x16dda0(0x89)), process[_0x16dda0(0x141)]());
fs[_0x16dda0(0xd0)](uafile) && (fs[_0x16dda0(0x10a)](uafile), console[_0x16dda0(0x9b)](uafile + _0x16dda0(0xe6)));
function _0x379f() {
    const _0xf1f59b = [
        '10.1',
        '\x20like\x20Geck',
        'floor',
        '3.1',
        '1.0',
        '\x20uagen\x20cou',
        'OS\x20X\x2010_13',
        'OS\x20X\x2010_11',
        'mXpsw',
        'Brave',
        'de-DE',
        'ed\x20',
        '2.0',
        '\x20OS',
        '1.4',
        'Vivaldi',
        '7.1',
        'Windows\x20CE',
        'ly\x20generat',
        'Chrome\x20OS',
        'ZHYwN',
        'Red\x20Hat',
        'wser',
        'Pale\x20Moon',
        '4.0',
        'x86',
        'Tizen',
        're\x20Browser',
        'architectu',
        'Intel\x20Mac\x20',
        'Android\x204',
        'Konqueror',
        'nt\x20file\x0aus',
        'exit',
        'NfbLu',
        '\x20user\x20agen',
        'Android\x207',
        'IceCat',
        'Android\x2011',
        'Anna',
        'Fedora',
        'Yandex\x20Bro',
        'Belle',
        '3.0',
        'ua.txt',
        'OS\x20X\x2010_14',
        'Android\x208',
        'Ubuntu',
        '131466LvfOfw',
        '217779QbuTFs',
        'Android\x206',
        '348104cXVsTU',
        '10.2',
        '13421.66.0',
        'Intel',
        '5.0',
        '5.2',
        '1.2',
        'length',
        'Win32',
        'name',
        'Epic\x20Priva',
        'log',
        'Android\x205',
        'Mozilla/5.',
        'Debian',
        'Elementary',
        '7.0',
        'Qutebrowse',
        'S60',
        'Android\x202',
        '568lvzlJZ',
        'ternet',
        '3.5',
        'Otter\x20Brow',
        '360\x20Secure',
        'Slackware',
        'argv',
        'Linux\x20Mint',
        '5.1',
        'xplorer',
        '33887mDmCbb',
        'Opera',
        '6769790rpNcYT',
        '8.1',
        '3.51',
        'Kali\x20Linux',
        'Cent\x20Brows',
        '8.0',
        'PPC\x20Mac\x20OS',
        '.0\x20(KHTML,',
        '13421.64.0',
        'Midori',
        'from',
        '.0\x20Safari/',
        '10.0',
        '3.11',
        'Gentoo',
        'ARM64',
        'Mozilla',
        'agent\x20100\x20',
        '6.3',
        'vjIVB',
        'Successful',
        'Android\x2010',
        'Raspbian',
        'en-GB',
        'Waterfox',
        'Firefox',
        'one',
        'Windows\x20NT',
        '13421.62.0',
        'Kit/',
        'age\x20node\x20u',
        'CentOS',
        'existsSync',
        'OS\x20X\x2010_15',
        '9kHiwcI',
        'ser',
        'Avast\x20Secu',
        'openSUSE',
        '2.11',
        'Slimjet',
        'fr-FR',
        'webOS',
        '13421.67.0',
        '4209381QCCbTz',
        'Chrome',
        '2.3',
        'Macintosh',
        'Arch\x20Linux',
        '10.3',
        '13421.63.0',
        'Linux',
        '13421.61.0',
        '1614rSZAjL',
        '6.1',
        '\x20deleted.',
        'join',
        'Lunascape',
        '6.2',
        'OS\x20X\x2010_12',
        ')\x20AppleWeb',
        '\x20X\x2010_4_11',
        'GreenBrows',
        'Windows\x20Ph',
        'Edge',
        'Puppy\x20Linu',
        'Bada',
        'Zorin\x20OS',
        'usage\x20node',
        'vJsuo',
        'PowerPC',
        '13421.60.0',
        'Android\x2012',
        'version',
        '68K',
        'Chromium\x20O',
        '2.1',
        '6.0',
        'o)\x20',
        '13421.65.0',
        'ARM',
        'Torch\x20Brow',
        'UC\x20Browser',
        'SeaMonkey',
        'Android',
        '7.5',
        'Maxthon',
        'X11',
        'Safari',
        'BackBox',
        '\x20X\x2010_5_8',
        'unlinkSync',
        'Netscape',
        'Internet\x20E',
        '2.2',
        'en-US',
        'hsJDQ',
        '0\x20(',
        'x86_64',
        'Samsung\x20In',
        'Win64',
        'random',
        'writeFile',
        'UtOgX',
        '2.4',
        '\x20Browser',
        '1555bPgJcd',
        'Symbian',
        'OXhbV',
        'cy\x20Browser',
        'BlackBerry',
        'Android\x209',
        'Mandriva'
    ];
    _0x379f = function () {
        return _0xf1f59b;
    };
    return _0x379f();
}
const browsers = [
        { 'name': _0x16dda0(0xc0) },
        { 'name': _0x16dda0(0xdc) },
        { 'name': _0x16dda0(0x107) },
        { 'name': _0x16dda0(0xef) },
        { 'name': _0x16dda0(0xaf) },
        { 'name': _0x16dda0(0xc9) },
        { 'name': _0x16dda0(0x10c) + _0x16dda0(0xad) },
        { 'name': _0x16dda0(0x129) },
        { 'name': _0x16dda0(0x12f) },
        { 'name': _0x16dda0(0x101) },
        { 'name': _0x16dda0(0x112) + _0x16dda0(0xa5) },
        { 'name': _0x16dda0(0x105) },
        { 'name': _0x16dda0(0x86) + _0x16dda0(0x136) },
        { 'name': _0x16dda0(0xa8) + _0x16dda0(0x118) },
        { 'name': _0x16dda0(0xd4) + _0x16dda0(0x13b) },
        { 'name': _0x16dda0(0xb4) + 'er' },
        { 'name': _0x16dda0(0x9a) + _0x16dda0(0x11c) },
        { 'name': _0x16dda0(0xed) + 'er' },
        { 'name': _0x16dda0(0xe8) },
        { 'name': _0x16dda0(0x100) + _0x16dda0(0xd3) },
        { 'name': _0x16dda0(0xc8) },
        { 'name': _0x16dda0(0x137) },
        { 'name': _0x16dda0(0x102) },
        { 'name': _0x16dda0(0xb9) },
        { 'name': _0x16dda0(0x13f) },
        { 'name': _0x16dda0(0x10b) },
        { 'name': _0x16dda0(0xd7) },
        { 'name': _0x16dda0(0x145) },
        { 'name': _0x16dda0(0xa1) + 'r' },
        { 'name': _0x16dda0(0xa7) + _0x16dda0(0xd3) }
    ], platforms = [
        {
            'name': _0x16dda0(0xcb),
            'version': [
                _0x16dda0(0xbc),
                _0x16dda0(0xc2),
                _0x16dda0(0xe9),
                _0x16dda0(0xe5),
                _0x16dda0(0xfc),
                _0x16dda0(0x95),
                _0x16dda0(0xac),
                _0x16dda0(0x94),
                _0x16dda0(0x138),
                _0x16dda0(0xb2),
                _0x16dda0(0xa6),
                _0x16dda0(0x123),
                _0x16dda0(0xbd),
                _0x16dda0(0x88),
                _0x16dda0(0xd6),
                _0x16dda0(0xfb),
                _0x16dda0(0x12c),
                _0x16dda0(0x124)
            ],
            'architecture': [
                _0x16dda0(0x113),
                _0x16dda0(0x98)
            ]
        },
        {
            'name': _0x16dda0(0xde),
            'version': [
                _0x16dda0(0x93),
                _0x16dda0(0x13d) + _0x16dda0(0xd1) + '_7',
                _0x16dda0(0x13d) + _0x16dda0(0x8a) + '_6',
                _0x16dda0(0x13d) + _0x16dda0(0x126) + '_6',
                _0x16dda0(0x13d) + _0x16dda0(0xea) + '_6',
                _0x16dda0(0x13d) + _0x16dda0(0x127) + '_6',
                _0x16dda0(0xf5),
                _0x16dda0(0xb6) + _0x16dda0(0xec),
                _0x16dda0(0xb6) + _0x16dda0(0x109),
                _0x16dda0(0xf9)
            ],
            'architecture': [
                _0x16dda0(0x111),
                _0x16dda0(0x139)
            ]
        },
        {
            'name': _0x16dda0(0x106),
            'version': [
                _0x16dda0(0x8c),
                _0x16dda0(0x85),
                _0x16dda0(0x9e),
                _0x16dda0(0x135),
                _0x16dda0(0xab),
                _0x16dda0(0xbe),
                _0x16dda0(0xd5),
                _0x16dda0(0xdf),
                _0x16dda0(0xa9),
                _0x16dda0(0xcf),
                _0x16dda0(0xb3),
                _0x16dda0(0xf0) + 'x',
                _0x16dda0(0xc6),
                _0x16dda0(0x11f),
                _0x16dda0(0x9f) + _0x16dda0(0x12d),
                _0x16dda0(0xf2),
                _0x16dda0(0x108),
                _0x16dda0(0xfa) + 'S'
            ],
            'architecture': [
                _0x16dda0(0x111),
                _0x16dda0(0x139)
            ]
        },
        {
            'name': _0x16dda0(0xe2),
            'version': [
                _0x16dda0(0x111),
                _0x16dda0(0x139),
                _0x16dda0(0xff),
                _0x16dda0(0xbf)
            ]
        },
        {
            'name': _0x16dda0(0x103),
            'version': [
                _0x16dda0(0xf7),
                _0x16dda0(0x146),
                _0x16dda0(0xc5),
                _0x16dda0(0x11e),
                _0x16dda0(0x8b),
                _0x16dda0(0x144),
                _0x16dda0(0x8f),
                _0x16dda0(0x9c),
                _0x16dda0(0x13e),
                _0x16dda0(0xa3)
            ],
            'architecture': [
                _0x16dda0(0xff),
                _0x16dda0(0xbf),
                _0x16dda0(0x139),
                _0x16dda0(0x111)
            ]
        },
        {
            'name': _0x16dda0(0x133),
            'version': [
                _0x16dda0(0xda),
                _0x16dda0(0x92),
                _0x16dda0(0xfe),
                _0x16dda0(0xb8),
                _0x16dda0(0xe1),
                _0x16dda0(0xcc),
                _0x16dda0(0xe3),
                _0x16dda0(0xf6)
            ],
            'architecture': [
                _0x16dda0(0x111),
                _0x16dda0(0x139)
            ]
        },
        {
            'name': _0x16dda0(0xee) + _0x16dda0(0xca),
            'version': [
                _0x16dda0(0xbc),
                _0x16dda0(0xb1),
                _0x16dda0(0xb5),
                _0x16dda0(0x104),
                _0x16dda0(0xa0)
            ],
            'architecture': [_0x16dda0(0xff)]
        },
        {
            'name': _0x16dda0(0x11d),
            'version': [
                _0x16dda0(0xe0),
                _0x16dda0(0x91),
                _0x16dda0(0x120),
                _0x16dda0(0xbc),
                _0x16dda0(0x130),
                _0x16dda0(0xfc)
            ],
            'architecture': [
                _0x16dda0(0xff),
                _0x16dda0(0x139)
            ]
        },
        {
            'name': _0x16dda0(0x131),
            'version': [
                _0x16dda0(0xa0),
                _0x16dda0(0xfc),
                _0x16dda0(0x94)
            ],
            'architecture': [
                _0x16dda0(0xff),
                _0x16dda0(0x139)
            ]
        },
        {
            'name': _0x16dda0(0x13a),
            'version': [
                _0x16dda0(0x138),
                _0x16dda0(0x88),
                _0x16dda0(0x117),
                _0x16dda0(0xdd)
            ],
            'architecture': [_0x16dda0(0xff)]
        },
        {
            'name': _0x16dda0(0x11a),
            'version': [
                _0x16dda0(0x87),
                _0x16dda0(0x147),
                _0x16dda0(0xa2)
            ],
            'architecture': [
                _0x16dda0(0xff),
                _0x16dda0(0x139)
            ]
        },
        {
            'name': _0x16dda0(0xd9),
            'version': [
                _0x16dda0(0x88),
                _0x16dda0(0x10d),
                _0x16dda0(0x12e),
                _0x16dda0(0x124)
            ],
            'architecture': [_0x16dda0(0xff)]
        },
        {
            'name': _0x16dda0(0xf1),
            'version': [
                _0x16dda0(0x12c),
                _0x16dda0(0x96),
                _0x16dda0(0x124)
            ],
            'architecture': [_0x16dda0(0xff)]
        }
    ], languages = [
        _0x16dda0(0x10e),
        _0x16dda0(0xc7),
        _0x16dda0(0xd8),
        _0x16dda0(0x12a)
    ];
function getRandomElement(_0x34375a) {
    const _0x126248 = _0x16dda0, _0x402ac2 = {
            'hsJDQ': function (_0x49eb4f, _0x2f912f) {
                return _0x49eb4f * _0x2f912f;
            }
        };
    return _0x34375a[Math[_0x126248(0x122)](_0x402ac2[_0x126248(0x10f)](Math[_0x126248(0x114)](), _0x34375a[_0x126248(0x97)]))];
}
function getRandomPlatform() {
    const _0x56c70c = _0x16dda0, _0x3aa955 = {
            'ZHYwN': function (_0x1f6877, _0x50e17a) {
                return _0x1f6877(_0x50e17a);
            },
            'vjIVB': function (_0x42b5b3, _0x2b0c5c) {
                return _0x42b5b3 > _0x2b0c5c;
            }
        }, _0x11f6d0 = _0x3aa955[_0x56c70c(0x134)](getRandomElement, platforms), _0x460a49 = _0x11f6d0[_0x56c70c(0x99)];
    let _0x17f4c9 = '', _0x36092b = '';
    return _0x11f6d0[_0x56c70c(0xf8)] && (_0x17f4c9 = '/' + _0x3aa955[_0x56c70c(0x134)](getRandomElement, _0x11f6d0[_0x56c70c(0xf8)])), _0x11f6d0[_0x56c70c(0x13c) + 're'] && _0x3aa955[_0x56c70c(0xc3)](_0x11f6d0[_0x56c70c(0x13c) + 're'][_0x56c70c(0x97)], 0x1 * -0x18bb + 0x1a71 + -0x1b6) && (_0x36092b = ';\x20' + _0x3aa955[_0x56c70c(0x134)](getRandomElement, _0x11f6d0[_0x56c70c(0x13c) + 're'])), '' + _0x460a49 + _0x17f4c9 + _0x36092b;
}
function getRandomBrowser() {
    const _0x22170c = _0x16dda0, _0x512f62 = {
            'mXpsw': function (_0x128cc0, _0x375fde) {
                return _0x128cc0(_0x375fde);
            }
        };
    return _0x512f62[_0x22170c(0x128)](getRandomElement, browsers);
}
const userAgents = Array[_0x16dda0(0xba)]({ 'length': count }, () => {
    const _0x105235 = _0x16dda0, _0xefebbb = {
            'OXhbV': function (_0x3e663a) {
                return _0x3e663a();
            },
            'NfbLu': function (_0x542df5, _0x3fbaa2) {
                return _0x542df5 + _0x3fbaa2;
            },
            'UtOgX': function (_0x1f94eb, _0x5b07b1) {
                return _0x1f94eb * _0x5b07b1;
            },
            'vJsuo': function (_0x353ef0, _0x35d404) {
                return _0x353ef0(_0x35d404);
            }
        }, _0x214688 = _0xefebbb[_0x105235(0x11b)](getRandomPlatform), _0x26b73f = _0xefebbb[_0x105235(0x11b)](getRandomBrowser), _0x446fc2 = _0xefebbb[_0x105235(0x142)](Math[_0x105235(0x122)](_0xefebbb[_0x105235(0x116)](Math[_0x105235(0x114)](), -0xfd0 + -0x10 * -0x67 + 0x992)), 0x2679 + -0x14d8 + 0x116f * -0x1), _0x5458c0 = _0xefebbb[_0x105235(0xf4)](getRandomElement, languages);
    return _0x105235(0x9d) + _0x105235(0x110) + _0x214688 + ';\x20' + _0x5458c0 + (_0x105235(0xeb) + _0x105235(0xcd)) + _0x446fc2 + (_0x105235(0xb7) + _0x105235(0x121) + _0x105235(0xfd)) + _0x26b73f[_0x105235(0x99)] + '/' + _0x446fc2 + _0x105235(0xbb) + _0x446fc2 + '.0';
});
fs[_0x16dda0(0x115)](uafile, userAgents[_0x16dda0(0xe7)]('\x0a'), _0x36ef0f => {
    const _0x92b441 = _0x16dda0;
    if (_0x36ef0f)
        throw _0x36ef0f;
    console[_0x92b441(0x9b)](_0x92b441(0xc4) + _0x92b441(0x132) + _0x92b441(0x12b) + count + (_0x92b441(0x143) + 'ts'));
});